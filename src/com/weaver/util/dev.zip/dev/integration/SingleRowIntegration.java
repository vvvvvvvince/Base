package com.weaver.util.dev.integration;

import com.weaver.util.dev.dao.DaoUtils;
import com.weaver.util.dev.log.DevLog;
import com.weaver.util.dev.log.LogFactory;
import org.apache.commons.lang.StringUtils;
import weaver.conn.RecordSet;

import java.util.*;

/**
 * @Title: SingleRowIntegration
 * 单行记录同步
 * Company: zlk
 * @author: fsl
 * @version: 1.0
 * create date: 2023/6/7
 **/
public class SingleRowIntegration {

    private LogFactory log = new DevLog();

    /**
     * @description:适用于处理单个数据同步
     * @author: fsl
     * @date: 2023/6/7 16:09
     * @param: baseInfo
     * @param: values
     * @param: isFormmodeid
     **/
    public void handler(Map<String, Object> baseInfo, List<Object> values,RecordSet rs) throws Exception {
        log.info("handler::start");
        String theOnlyCheckRemoteFields = (String)baseInfo.get("TheOnlyCheck");
        if(StringUtils.isNotBlank(theOnlyCheckRemoteFields)){
            if(!isDataExit(baseInfo,rs)){
                /*新增*/
                insertLocalOaTableWithNoColHandler(baseInfo,values,rs);
            }else{
                /*修改*/
                updateLocalOaTable(baseInfo,values,rs);
            }
        }else{
            insertLocalOaTableWithNoColHandler(baseInfo,values,rs);
        }
    }


    /**
     * 插入本地oa values为值数组与字段的位置应该保持一致
     */
    public void insertLocalOaTableWithNoColHandler(Map<String,Object> baseInfo
            , List<Object> values
            , RecordSet rs) throws Exception {
        log.info("insertLocalOaTableWithNoColHandler::execute");
        String localFields = (String)baseInfo.get("LocalFields");
        List<String> paramsOrg = Arrays.asList(localFields.split(","));
        List<String> params = new ArrayList<>(paramsOrg);
        params.add("uuid");
        values.add(""+UUID.randomUUID());
        DaoUtils.insertFormmode((String)baseInfo.get("LocalSynchronousTable"),params,values
                ,Integer.valueOf(""+baseInfo.get("formmodeid")),rs);
    }


    public void updateLocalOaTable(Map<String, Object> baseInfo,
                                   List<Object> list,RecordSet rs) throws Exception {
        log.info("updateLocalOaTable::execute");
        String localFields = (String)baseInfo.get("LocalFields");
        String[] fields = localFields.split(",");
        List<String> orgFields = Arrays.asList(fields);
        List<String> fieldList = new ArrayList<>(orgFields);
        if(StringUtils.isBlank(localFields)){
            throw new Exception("本地字段读取不到");
        }
        String theOnlyCheck = (String)baseInfo.get("TheOnlyCheck");
        String[] Checks = theOnlyCheck.split(",");
        List<String> checkListOrg = Arrays.asList(Checks);
        List<String> condition = new ArrayList<>(checkListOrg);
        String localSynchronousTable = (String)baseInfo.get("LocalSynchronousTable");
        List<String> checkFieldValues = (List)baseInfo.get("checkFieldValues");
        for (String fieldValues:checkFieldValues){
            list.add(fieldValues);
        }
        DaoUtils.update(localSynchronousTable,fieldList,list,condition,rs);
    }


    /**
     * 是否存在数据 检查数据唯一性 场景1 只包含一个表,只考虑唯一性字段只有一个
     * @param baseInfo
     * @return
     */
    public boolean isDataExit(Map<String, Object> baseInfo, RecordSet srs) {
        log.info("isDataExit::-->execute");
        List<String> checkFieldValues = (List)baseInfo.get("checkFieldValues");
        String localSynchronousTable = (String)baseInfo.get("LocalSynchronousTable");
        boolean flag = false;
        String theOnlyCheck = (String)baseInfo.get("TheOnlyCheck");
        StringBuilder sql = new StringBuilder("select count(*) from " + localSynchronousTable+" where");
        String[] Checks = theOnlyCheck.split(",");
        for (int i = 0; i < Checks.length; i++) {
            if(i!=Checks.length-1){
                sql.append(" "+Checks[i]+"='"+checkFieldValues.get(i)+"' and");
            }else{
                sql.append(" "+Checks[i]+"='"+checkFieldValues.get(i)+"'");
            }
        }
        log.info("查询当前是否存在数据-->sql::" + sql.toString());
        if(srs.execute(sql.toString())){
            srs.next();
            int num = srs.getInt(1);
            log.info("查询当前是否存在数据-->num::" + num);
            if (num > 0) {
                flag = true;
            }
            log.info("isDataExit-return:"+flag);
            return flag;
        }else{
            log.error(sql+"执行错误::"+srs.getExceptionMsg());
            return flag;
        }
    }


}
