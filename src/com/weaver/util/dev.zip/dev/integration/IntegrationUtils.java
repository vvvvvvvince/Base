package com.weaver.util.dev.integration;

import com.weaver.util.dev.date.DateUtils;
import com.weaver.util.dev.log.DevLog;
import com.weaver.util.dev.log.LogFactory;
import ebu.util.EbuBaseDevUtils;
import org.apache.commons.lang.StringUtils;
import weaver.conn.RecordSet;
import weaver.conn.RecordSetDataSource;
import weaver.general.GCONST;
import weaver.general.Util;
import weaver.integration.logging.Logger;
import weaver.integration.logging.LoggerFactory;

import java.io.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author slfang
 * @date 2021-09-24 13:37
 *
 */
public abstract class IntegrationUtils {

    public LogFactory logger = new DevLog();
    public EbuBaseDevUtils baseBean = new EbuBaseDevUtils();
    int modedatacreater = 1; //1-系统管理员
    int modedatacreatertype = 0;//创建人类型，默认为0
    String modedatacreatedate = DateUtils.getDate("yyyy-MM-dd");//模块创建日期
    String modedatacreatetime = DateUtils.getDate("HH:mm:ss");//模块创建时间
    String modedatamodifydatetime = DateUtils.getDate("yyyy-MM-dd HH:mm:ss");//模块创建时间
    List<String> DOUBLE_INDEX_LIST = null;


    public static final String RS_TYPE_LOCAL="LOCAL";
    public static final String RS_TYPE_REMOTE="REMOTE";




    public Map<String,Object> getBaseInfo(String fileName){
        logger.info("getBaseInfo");
        Map<String,Object> baseInfo = new HashMap<>();
        baseBean.readProAndSetMap(fileName,baseInfo);
        return baseInfo;
    }

    public void  handler(Map<String,Object> baseInfo,String fileName) throws Exception {
        logger.info(fileName+"::::::::::::::::::::::::::::::::::::::::::::::::::start");
        //logger.info("handler:start");
        String theOnlyCheckRemoteFields = (String)baseInfo.get("TheOnlyCheckRemoteFields");
        String DOUBLE_INDEX = (String)baseInfo.get("DOUBLE_INDEX");
        if(StringUtils.isNotBlank(DOUBLE_INDEX)){
            DOUBLE_INDEX_LIST = Arrays.asList(DOUBLE_INDEX.split(","));
        }
        if(StringUtils.isNotBlank(theOnlyCheckRemoteFields)){
            String[] theOnlyCheckRemoteFieldsArr = theOnlyCheckRemoteFields.split(",");
            handlerDataWithCheckByType(theOnlyCheckRemoteFieldsArr,baseInfo);
        }else{
            handlerDataWithNoCheckByType(baseInfo);
        }

        String is_delete = ""+baseInfo.get("is_delete");
        //处理跟新删除状态
        if(StringUtils.isNotBlank(is_delete)&&!"null".equals(is_delete)){
            String updateSql="update "+baseInfo.get("LocalSynchronousTable")+" set "+is_delete+
                    "=-1 where modedatamodifydatetime!='"+modedatamodifydatetime+"' or modedatamodifydatetime is null" ;
            logger.info("updateSql::"+updateSql);
            RecordSet rs = new RecordSet();
            rs.execute(updateSql);
        }
        logger.info(fileName+"::::::::::::::::::::::::::::::::::::::::::::::::::end");
    }



    abstract void handlerDataWithCheckByType(String[] theOnlyCheckFieldsArr,
                                             Map<String, Object> baseInfo
    ) throws Exception ;

    abstract void handlerDataWithNoCheckByType(Map<String, Object> baseInfo) throws Exception;


    /**
     * 配置文件读取解决中文乱码：  propValue = new String(propValue.getBytes("ISO-8859-1"),"UTF-8");
     * 读取配置设置map
     * @param fileName 配置文件名
     * @throws IOException
     * version 2.0
     */
    public void readProAndSetMap(String fileName, Map<String, Object> baseInfo)  {
        logger.info("readProAndSetMap::start:::::::::::::::::::::::::::::::::");
        String path= GCONST.getPropertyPath()+fileName + ".properties";
        File file = new File(path);
        BufferedReader in = null;
        try {
            InputStreamReader isr = new InputStreamReader(new FileInputStream(file), "UTF-8");
            in = new BufferedReader(isr);
            String string="";
            while ((string = in.readLine())!=null){
                if(StringUtils.isNotBlank(string)&&!string.startsWith("#")){
                    logger.info("配置信息::"+string);
                    String[] lineValue = string.split("=");
                    int i = string.indexOf("=");
                    if(string.length()==i+1||i==-1){
                        baseInfo.put(lineValue[0],"");
                    }else{
                        baseInfo.put(lineValue[0],string.substring(i+1,string.length()));
                    }
                }
            }
            logger.info("hashMap::"+baseInfo);
            logger.info("readProAndSetMap::end:::::::::::::::::::::::::::::::::");
        } catch (Exception e) {
            e.printStackTrace();
            logger.info(e.getMessage());
        }
        finally {
            try {
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
                logger.info(e.getMessage());
            }
        }
    }



    /**
     * 获取插入sql 前缀
     * @return
     */
    public StringBuilder getInsertLocalSqlPre(Map<String,Object> baseInfo) throws Exception {
        StringBuilder sqlInsert = new StringBuilder(" insert into "+baseInfo.get("LocalSynchronousTable"));
        String localFields = (String)baseInfo.get("LocalFields");
        if(StringUtils.isBlank(localFields)){
            throw new Exception("本地字段读取不到");
        }
        sqlInsert.append("(");
        String[] split_localFields = localFields.split(",");
        for (int i = 0; i < split_localFields.length; i++) {
            if(i==0){
                sqlInsert.append(split_localFields[i]);
            }else{
                sqlInsert.append(","+split_localFields[i]);
            }
        }
        String  formmodeid = (String)baseInfo.get("formmodeid");
        if(StringUtils.isNotBlank(formmodeid)){
            sqlInsert.append(",formmodeid,");
            sqlInsert.append("modedatacreater,");
            sqlInsert.append("modedatacreatertype,");
            sqlInsert.append("modedatacreatedate,");
            sqlInsert.append("modedatacreatetime,");
            sqlInsert.append("modedatamodifydatetime");
        }
        sqlInsert.append(") VALUES(");
        return sqlInsert;
    }

    /**
     * 获取插入sql 后缀
     * @return
     */
    public StringBuilder getInsertLocalSqlEnd(Map<String,Object> baseInfo,List<String> vals) throws Exception {
        StringBuilder sqlInsert = new StringBuilder();
        for (int i = 0; i < vals.size(); i++) {
            String val="";
            if(DOUBLE_INDEX_LIST!=null&&DOUBLE_INDEX_LIST.contains(""+i)){
                val=StringUtils.isBlank(vals.get(i))?""+0:vals.get(i);
            }else{
                val="'"+vals.get(i)+"'";
            }
            if(i==0){
                sqlInsert.append(" "+val+"");
            }else{
                sqlInsert.append(","+val+"");
            }
        }
        String  formmodeid = (String)baseInfo.get("formmodeid");
        if(StringUtils.isNotBlank(formmodeid)){
            sqlInsert.append(",'"+formmodeid+"',");
            sqlInsert.append("'"+modedatacreater+"',");
            sqlInsert.append("'"+modedatacreatertype+"',");
            sqlInsert.append("'"+modedatacreatedate+"',");
            sqlInsert.append("'"+modedatacreatetime+"',");
            sqlInsert.append("'"+modedatamodifydatetime+"'");
        }
        sqlInsert.append(")");
        return sqlInsert;
    }

    void buildUfAuth(String table,RecordSet rs,String formmodeid){
        if("null".equals(formmodeid)||StringUtils.isBlank(formmodeid)){
            return ;
        }
        String id = baseBean.getMaxId(table,rs);
        weaver.formmode.setup.ModeRightInfo moderightinfo = new weaver.formmode.setup.ModeRightInfo();
        moderightinfo.setNewRight(true);
        moderightinfo.editModeDataShare(modedatacreater,Integer.valueOf(formmodeid), Integer.valueOf(id));

    }


    /**
     * 跟新本地oa values为值数组与字段的位置应该保持一致
     * @param baseInfo
     * @param list 为唯一性值
     */
    public void updateLocalOaTable(Map<String, Object> baseInfo,
                                     Object reRs, List<String> list,RecordSet rs,String TYPE) throws Exception {
        logger.info("updateLocalOaTable::execute");
        StringBuilder sqlInsert = new StringBuilder(" update "+baseInfo.get("LocalSynchronousTable")+" set ");
        String localFields = (String)baseInfo.get("LocalFields");
        if(StringUtils.isBlank(localFields)){
            throw new Exception("本地字段读取不到");
        }
        String[] split_localFields = localFields.split(",");
        String remoteFields=(String) baseInfo.get("RemoteFields");
        String[] valuesFields = remoteFields.split(",");

        for (int i = 0; i < split_localFields.length; i++) {
            String value="";
            if(RS_TYPE_LOCAL.equals(TYPE)){
                RecordSet reRs2 = (RecordSet) reRs;
                value = Util.null2String(reRs2.getString(valuesFields[i]));
            }else{
                RecordSetDataSource  reRs2 = (RecordSetDataSource) reRs;
                value = Util.null2String(reRs2.getString(valuesFields[i]));
            }

            if(DOUBLE_INDEX_LIST!=null&&DOUBLE_INDEX_LIST.contains(""+i)){

            }else{
                value="'"+value+"'";
            }
            if(i==0){
                sqlInsert.append(split_localFields[i]+"="+value);
            }else{
                sqlInsert.append(","+split_localFields[i]+"="+value);
            }
        }
        sqlInsert.append(",modedatamodifydatetime='"+modedatamodifydatetime+"'");
        String theOnlyCheck = (String)baseInfo.get("TheOnlyCheck");
        String[] Checks = theOnlyCheck.split(",");
        for (int i = 0; i < Checks.length; i++) {
            if(i==0){
                sqlInsert.append(" where");
            }
            if(i!=Checks.length-1){
                sqlInsert.append(" "+Checks[i]+"='"+list.get(i)+"' and");
            }else{
                sqlInsert.append(" "+Checks[i]+"='"+list.get(i)+"'");
            }
        }
        logger.info("跟新sql::"+sqlInsert.toString());
        rs.execute(sqlInsert.toString());
    }


    /**
     * 跟新本地oa values为值数组与字段的位置应该保持一致
     * @param baseInfo
     * @param list 为唯一性值
     */
    public void updateLocalOaTable(Map<String, Object> baseInfo,
                                   List<String> values, List<String> list,RecordSet rs) throws Exception {
        logger.info("updateLocalOaTableWithNoColHandler::execute");
        logger.info("跟新数据::");
        StringBuilder sqlInsert = new StringBuilder(" update "+baseInfo.get("LocalSynchronousTable")+" set ");
        String localFields = (String)baseInfo.get("LocalFields");
        if(StringUtils.isBlank(localFields)){
            throw new Exception("本地字段读取不到");
        }
        String[] split_localFields = localFields.split(",");
        String remoteFields=(String) baseInfo.get("RemoteFields");
        String[] valuesFields = remoteFields.split(",");

        for (int i = 0; i < split_localFields.length; i++) {
            String value=values.get(i);
            if(DOUBLE_INDEX_LIST!=null&&DOUBLE_INDEX_LIST.contains(""+i)){
            }else{
                value="'"+value+"'";
            }
            if(i==0){
                sqlInsert.append(split_localFields[i]+"="+value+"");
            }else{
                sqlInsert.append(","+split_localFields[i]+"="+value+"");
            }
        }
        sqlInsert.append(",modedatamodifydatetime='"+modedatamodifydatetime+"'");
        String theOnlyCheck = (String)baseInfo.get("TheOnlyCheck");
        String[] Checks = theOnlyCheck.split(",");
        for (int i = 0; i < Checks.length; i++) {
            if(i==0){
                sqlInsert.append(" where");
            }
            if(i!=Checks.length-1){
                sqlInsert.append(" "+Checks[i]+"='"+list.get(i)+"' and");
            }else{
                sqlInsert.append(" "+Checks[i]+"='"+list.get(i)+"'");
            }
        }

        logger.info("跟新sql::"+sqlInsert.toString());
        rs.execute(sqlInsert.toString());
    }

    /**
     * 执行sql获取第三方数据
     * @return
     */
    public RecordSetDataSource getRemoteData(Map<String,Object> baseInfo){
        logger.info("getRemoteData::-->execute");
        String remoteSql = (String)baseInfo.get("RemoteSql");
        logger.info("remoteSql::"+remoteSql);
        RecordSetDataSource remoteDataSource = new RecordSetDataSource(""+baseInfo.get("dataSourceName"));
        remoteDataSource.execute(remoteSql);
        return remoteDataSource;
    }


    /**
     * 执行sql获取本地表数据，用于与本地数据 做集成
     * @return
     */
    public RecordSet getLocalData(Map<String,Object> baseInfo){
        logger.info("getLocalData::-->execute");
        RecordSet recordSet = new RecordSet();
        String remoteSql = (String)baseInfo.get("RemoteSql");
        logger.info("RemoteSql::"+remoteSql);
        recordSet.execute(remoteSql);
        return recordSet;
    }



    /**
     * 是否存在数据 检查数据唯一性 场景1 只包含一个表,只考虑唯一性字段只有一个
     * @param baseInfo
     * @return
     */
    public boolean isDataExit(Map<String, Object> baseInfo, List<String> checkFieldValues) {
        logger.info("isDataExit::-->execute");
        String localSynchronousTable = (String)baseInfo.get("LocalSynchronousTable");
        boolean flag = false;
        String theOnlyCheck = (String)baseInfo.get("TheOnlyCheck");
        StringBuilder sql = new StringBuilder("select count(*) from " + localSynchronousTable+" where");
        String[] Checks = theOnlyCheck.split(",");
        for (int i = 0; i < Checks.length; i++) {
            if(i!=Checks.length-1){
                sql.append(" "+Checks[i]+"='"+checkFieldValues.get(i)+"' and");
            }else{
                sql.append(" "+Checks[i]+"='"+checkFieldValues.get(i)+"'");
            }
        }
        logger.info("查询当前是否存在数据-->sql::" + sql.toString());
        RecordSet srs = new RecordSet();
        srs.execute(sql.toString());
        srs.next();
        int num = srs.getInt(1);
        logger.info("查询当前是否存在数据-->num::" + num);
        if (num > 0) {
            flag = true;
        }
        logger.info("isDataExit-return:"+flag);
        return flag;
    }

    /**
     * 是否存在数据 检查数据唯一性 场景1 只包含一个表,只考虑唯一性字段只有一个
     * @param baseInfo
     * @return
     */
    public boolean isDataExit(Map<String, Object> baseInfo) {
        logger.info("isDataExit::-->execute");
        List<String> checkFieldValues = (List<String>) baseInfo.get("checkFieldValues");
        String localSynchronousTable = (String)baseInfo.get("LocalSynchronousTable");
        boolean flag = false;
        String theOnlyCheck = (String)baseInfo.get("TheOnlyCheck");
        StringBuilder sql = new StringBuilder("select count(*) from " + localSynchronousTable+" where");
        String[] Checks = theOnlyCheck.split(",");
        for (int i = 0; i < Checks.length; i++) {
            if(i!=Checks.length-1){
                sql.append(" "+Checks[i]+"='"+checkFieldValues.get(i)+"' and");
            }else{
                sql.append(" "+Checks[i]+"='"+checkFieldValues.get(i)+"'");
            }
        }
        logger.info("查询当前是否存在数据-->sql::" + sql.toString());
        RecordSet srs = new RecordSet();
        srs.execute(sql.toString());
        srs.next();
        int num = srs.getInt(1);
        logger.info("查询当前是否存在数据-->num::" + num);
        if (num > 0) {
            flag = true;
        }
        logger.info("isDataExit-return:"+flag);
        return flag;
    }
}
