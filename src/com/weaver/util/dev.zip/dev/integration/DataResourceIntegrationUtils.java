package com.weaver.util.dev.integration;

import org.apache.commons.lang.StringUtils;
import weaver.conn.RecordSet;
import weaver.conn.RecordSetDataSource;
import weaver.general.Util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @Description 数据源集成标准工具类  ,当前可以同步远程数据源以及本地数据源
#*               1、配置第三方数据库查询语句名称为RemoteSql
#*              2、配置本地同步数据表明称为LocalSynchronousTable
#*              3、配置文件要与定时任务接口配置的FileName名称一致
#*              4、需要唯一校验且配置，不需要则不配置，当配置只涉及一张表时设置配置唯一性字段且字段名称为TheOnlyCheck【本地字段】,TheOnlyCheckRemoteFields【远程字段】
#*              5、配置数据源名称
#*              6、配置第三方数据库字段名称 RemoteFields 多个用逗号隔开
#*              7、RemoteFields 要与LocalFields中查询的字段要一一对应上去
 * @Author fangshilei
 * @Date 2019/11/11 17:22
 * @Version 1.0
 **/
public  class DataResourceIntegrationUtils extends IntegrationUtils {



    /**
     * 集成数据无需检验唯一性
     * @param baseInfo
     * @throws Exception
     */
    @Override
    public void handlerDataWithNoCheckByType(Map<String, Object> baseInfo) throws Exception {
        String dataSourceName = (String)baseInfo.get("dataSourceName");
        RecordSet rs2 = new RecordSet();
        if(StringUtils.isBlank(dataSourceName)){
            RecordSet rs = getLocalData(baseInfo);
            while (rs.next()){
                insertLocalOaTableWithNoColHandler(baseInfo,rs,rs2);
            }
        }else{
            RecordSetDataSource remoteData = getRemoteData(baseInfo);
            while (remoteData.next()){
                insertLocalOaTableWithNoColHandler(baseInfo,remoteData,rs2);
            }
        }
    }



    /**
     * @param theOnlyCheckRemoteFieldsArr  集成数据带有唯一性校验
     * @param baseInfo
     * @throws Exception
     */
    @Override
    public void handlerDataWithCheckByType(String[] theOnlyCheckRemoteFieldsArr,
                                            Map<String, Object> baseInfo
            ) throws Exception {
        String dataSourceName = (String)baseInfo.get("dataSourceName");
        RecordSet rs =new RecordSet();
        List<String> list=null;
        if(StringUtils.isBlank(dataSourceName)){
            RecordSet localData = getLocalData(baseInfo);
            while (localData.next()){
                list = new ArrayList<>();
                for (String s : theOnlyCheckRemoteFieldsArr) {
                    String reCheckFieldValue = localData.getString(s);
                    list.add(reCheckFieldValue);
                    logger.info("远程唯一新校验字段名："+s+"----value::"+reCheckFieldValue);
                }
                if(!isDataExit(baseInfo,list)){
                    /*新增*/
                    insertLocalOaTableWithNoColHandler(baseInfo,localData,rs);
                }else{
                    /*修改*/
                    updateLocalOaTableWithNoColHandler(baseInfo,localData,list,rs);
                }
            }
        }else{
            RecordSetDataSource remoteData = getRemoteData(baseInfo);
            while (remoteData.next()){
                list = new ArrayList<>();
                for (String s : theOnlyCheckRemoteFieldsArr) {
                    String reCheckFieldValue = remoteData.getString(s);
                    list.add(reCheckFieldValue);
                    logger.info("远程唯一新校验字段名："+s+"----value::"+reCheckFieldValue);
                }
                if(!isDataExit(baseInfo,list)){
                    /*新增*/
                    insertLocalOaTableWithNoColHandler(baseInfo,remoteData,rs);
                }else{
                    /*修改*/
                    updateLocalOaTableWithNoColHandler(baseInfo,remoteData,list,rs);
                }
            }
        }
    }

    /**
     * 插入本地oa values为值数组与字段的位置应该保持一致
     */
    public void insertLocalOaTableWithNoColHandler(Map<String,Object> baseInfo,RecordSet reRs,RecordSet rs) throws Exception {
        logger.info("insertLocalOaTableWithNoColHandler::execute");
        StringBuilder insertLocalSqlPre = getInsertLocalSqlPre(baseInfo);
        String remoteFileds=(String)baseInfo.get("RemoteFields");
        String[] valuesFilds = remoteFileds.split(",");
        List<String> vals = new ArrayList<>();
        for (int i = 0; i < valuesFilds.length; i++) {
            vals.add(Util.null2String(reRs.getString(valuesFilds[i])));
        }
        StringBuilder insertLocalSqlEnd = getInsertLocalSqlEnd(baseInfo, vals);
        insertLocalSqlPre.append(insertLocalSqlEnd);
        logger.info("插入sql::"+insertLocalSqlPre.toString());
        rs.execute(insertLocalSqlPre.toString());
        String ufTable = (String)baseInfo.get("LocalSynchronousTable");
        String  formmodeid = ""+baseInfo.get("formmodeid");
        buildUfAuth(ufTable,rs,formmodeid);
    }

    /**
     * 插入本地oa values为值数组与字段的位置应该保持一致
     */
    public void insertLocalOaTableWithNoColHandler(Map<String,Object> baseInfo
            ,RecordSetDataSource reRs
            ,RecordSet rs) throws Exception {
        logger.info("insertLocalOaTableWithNoColHandler::execute");
        StringBuilder insertLocalSqlPre = getInsertLocalSqlPre(baseInfo);
        String remoteFileds=(String)baseInfo.get("RemoteFields");
        String[] valuesFilds = remoteFileds.split(",");
        List<String> vals = new ArrayList<>();
        for (int i = 0; i < valuesFilds.length; i++) {
            vals.add(Util.null2String(reRs.getString(valuesFilds[i])));
        }
        StringBuilder insertLocalSqlEnd = getInsertLocalSqlEnd(baseInfo, vals);
        insertLocalSqlPre.append(insertLocalSqlEnd);
        logger.info("插入sql::"+insertLocalSqlPre.toString());
        rs.execute(insertLocalSqlPre.toString());
        String ufTable = (String)baseInfo.get("LocalSynchronousTable");
        String  formmodeid = ""+baseInfo.get("formmodeid");
        buildUfAuth(ufTable,rs,formmodeid);
    }


    /**
     * 跟新本地oa values为值数组与字段的位置应该保持一致
     * @param baseInfo
     * @param reRs
     * @param list
     */
    public void updateLocalOaTableWithNoColHandler(Map<String, Object> baseInfo, RecordSet reRs, List<String> list,RecordSet rs) throws Exception {
        updateLocalOaTable(baseInfo,reRs,list,rs,RS_TYPE_LOCAL);
    }


    /**
     * 跟新本地oa values为值数组与字段的位置应该保持一致
     * @param baseInfo
     * @param reRs
     * @param list
     */
    public void updateLocalOaTableWithNoColHandler(Map<String, Object> baseInfo,
                                                   RecordSetDataSource reRs, List<String> list,RecordSet rs) throws Exception {
        updateLocalOaTable(baseInfo,reRs,list,rs,RS_TYPE_REMOTE);
    }


}
