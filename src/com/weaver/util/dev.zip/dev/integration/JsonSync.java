package com.weaver.util.dev.integration;
import net.sf.json.JSONArray;
import java.util.Map;
/**
 * @program: ebuCodes
 * @ClassName JsonSync
 * @description: json数据同步接口请求标准父类
 * @author: slfang
 * @create: 2023-07-04 10:22
 * @Version 1.0
 **/
public interface JsonSync {

    public JSONArray execute(Map<String,Object> baseInfo) throws Exception;

}
