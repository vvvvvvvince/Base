package com.weaver.util.dev.integration;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import weaver.conn.RecordSet;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 使用参照  SyHrmJob
 * @author slfang
 * @date 2021-09-24 13:39
 *
 */
public class JsonResourceIntegrationUtils extends IntegrationUtils {



    /**
     * 插入本地oa values为值数组与字段的位置应该保持一致 获取id根据主键自增原则来获取
     *    全量插入每次插入先清空之前的数据  处理json对象的字段包含对象
     * @param baseInfo 基础信息
     * @param job 传递过来的json数据
     * @param rs 执行对象
     * @throws Exception
     */
    public void insertLocalOaTableWithNoColHandler(Map<String,Object> baseInfo,JSONObject job,RecordSet rs) throws Exception {
        logger.info("insertLocalOaTableWithNoColHandler::execute");
        StringBuilder insertLocalSqlPre = getInsertLocalSqlPre(baseInfo);
        String remoteFileds=(String)baseInfo.get("RemoteFields");
        String[] valuesFilds = remoteFileds.split(",");
        List<String> values = new ArrayList<>();
        for (int i = 0; i < valuesFilds.length; i++) {
            String value = ""+job.get(valuesFilds[i]);
            values.add(value);
        }
        insertLocalSqlPre.append(getInsertLocalSqlEnd(baseInfo,values));
        logger.info("插入sql::::::::::::::::::::::::::::::::::::::"+insertLocalSqlPre.toString());
        //插入并生成模块权限
        rs.execute(insertLocalSqlPre.toString());
        String ufTable = (String)baseInfo.get("LocalSynchronousTable");
        String  formmodeid = ""+baseInfo.get("formmodeid");
        buildUfAuth(ufTable,rs,formmodeid);
    }


    @Override
    void handlerDataWithCheckByType(String[] theOnlyCheckRemoteFieldsArr, Map<String, Object> baseInfo) throws Exception {
        JSONArray json = (JSONArray) baseInfo.get("jsonArr");
        RecordSet rs = new RecordSet();
        List<String> list = null;
        List<String> listVal = null;
        for (int j = 0; j< json.size(); j++) {
            JSONObject job = json.getJSONObject(j);
            list = new ArrayList<>();
            for (String s : theOnlyCheckRemoteFieldsArr) {
                String reCheckFieldValue = ""+job.get(s);
                list.add(reCheckFieldValue);
                logger.info("远程唯一新校验字段名："+s+"----value::"+reCheckFieldValue);
            }
            if(!isDataExit(baseInfo,list)){
                /*新增*/
                insertLocalOaTableWithNoColHandler(baseInfo,job,rs);
            }else{
                /*修改*/
                listVal =  new ArrayList<>();
                String remoteFields=(String)baseInfo.get("RemoteFields");
                String[] valuesFields = remoteFields.split(",");
                for (int i = 0; i < valuesFields.length; i++) {
                    listVal.add(""+job.get(valuesFields[i]));
                }
                updateLocalOaTable(baseInfo,listVal,list,rs);
            }
        }
    }

    @Override
    void handlerDataWithNoCheckByType(Map<String, Object> baseInfo) throws Exception {
        String requestRes = baseBean.sentGet((String) baseInfo.get("dataRequestUrl"));
        logger.info("requestRes:::::::::::::::::::::::::::::::::::::::::\n"+requestRes);
        JSONArray json = JSONArray.fromObject(requestRes);
        RecordSet rs = new RecordSet();
        for (int j = 0; j< json.size(); j++) {
            JSONObject job = json.getJSONObject(j);
            insertLocalOaTableWithNoColHandler(baseInfo,job,rs);
        }
    }

}
